// Entry point for Command Center Dashboard
