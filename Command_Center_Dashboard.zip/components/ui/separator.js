// Separator component
