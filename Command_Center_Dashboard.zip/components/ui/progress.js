// Progress bar component
